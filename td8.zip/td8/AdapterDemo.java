 class DataAdaptee{
    public void PrintAdaptee(){
    System.out.println("Je suis de la classe DataAdaptee");
    }
    }
   
abstract class DataAdapterAbstract{
    public abstract void Print(); 
}

class DataAdapterConcrete extends DataAdapterAbstract {
    private DataAdaptee aDataAdaptee;

    public DataAdapterConcrete() {   
        aDataAdaptee = new DataAdaptee(); 
    }

    public void Print() { 
        aDataAdaptee.PrintAdaptee();
    }
}


public class AdapterDemo {
    private DataAdapterAbstract aDataTarget;

    public AdapterDemo() {
        aDataTarget = new DataAdapterConcrete();
        aDataTarget.Print();
    }

    public static void main(String[] args) {
        new AdapterDemo();
    }
}